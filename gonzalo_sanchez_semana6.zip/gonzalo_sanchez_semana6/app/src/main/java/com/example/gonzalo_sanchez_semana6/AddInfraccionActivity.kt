package com.example.gonzalo_sanchez_semana6

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gonzalo_sanchez_semana6.R

class AddInfraccionActivity : AppCompatActivity() {

    private lateinit var editTextRutInspector: EditText
    private lateinit var editTextNombreLocal: EditText
    private lateinit var editTextDireccion: EditText
    private lateinit var editTextInfraccion: EditText
    private lateinit var buttonSaveInfraccion: Button

    private lateinit var infraccionRepository: InfraccionRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_infraccion)

        infraccionRepository = InfraccionRepository(this)

        editTextRutInspector = findViewById(R.id.editTextRutInspector)
        editTextNombreLocal = findViewById(R.id.editTextNombreLocal)
        editTextDireccion = findViewById(R.id.editTextDireccion)
        editTextInfraccion = findViewById(R.id.editTextInfraccion)
        buttonSaveInfraccion = findViewById(R.id.buttonSaveInfraccion)

        buttonSaveInfraccion.setOnClickListener {
            saveInfraccion()
        }
    }

    private fun saveInfraccion() {
        val rutInspector = editTextRutInspector.text.toString()
        val nombreLocal = editTextNombreLocal.text.toString()
        val direccion = editTextDireccion.text.toString()
        val infraccion = editTextInfraccion.text.toString()

        if (rutInspector.isNotEmpty() && nombreLocal.isNotEmpty() && direccion.isNotEmpty() && infraccion.isNotEmpty()) {
            val folio = infraccionRepository.insertInfraccion(rutInspector, nombreLocal, direccion, infraccion)
            Toast.makeText(this, "Infracción guardada con folio: $folio", Toast.LENGTH_LONG).show()
            finish()
        } else {
            Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show()
        }
    }
}
