package com.example.gonzalo_sanchez_semana6

import android.content.ContentValues
import android.content.Context
import packete.DatabaseHelper

class InfraccionRepository(context: Context) {

    private val dbHelper = DatabaseHelper(context)

    fun insertInfraccion(rutInspector: String, nombreLocal: String, direccion: String, infraccion: String): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(DatabaseHelper.COLUMN_RUT_INSPECTOR, rutInspector)
            put(DatabaseHelper.COLUMN_NOMBRE_LOCAL, nombreLocal)
            put(DatabaseHelper.COLUMN_DIRECCION, direccion)
            put(DatabaseHelper.COLUMN_INFRACCION, infraccion)
        }
        return db.insert(DatabaseHelper.TABLE_NAME, null, values)
    }

    fun updateInfraccion(folio: Long, rutInspector: String, nombreLocal: String, direccion: String, infraccion: String): Int {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(DatabaseHelper.COLUMN_RUT_INSPECTOR, rutInspector)
            put(DatabaseHelper.COLUMN_NOMBRE_LOCAL, nombreLocal)
            put(DatabaseHelper.COLUMN_DIRECCION, direccion)
            put(DatabaseHelper.COLUMN_INFRACCION, infraccion)
        }
        return db.update(DatabaseHelper.TABLE_NAME, values, "${DatabaseHelper.COLUMN_ID} = ?", arrayOf(folio.toString()))
    }

    fun getAllInfracciones(): List<Infraccion> {
        val db = dbHelper.readableDatabase
        val cursor = db.query(DatabaseHelper.TABLE_NAME, null, null, null, null, null, null)
        val infracciones = mutableListOf<Infraccion>()
        with(cursor) {
            while (moveToNext()) {
                val folio = getLong(getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID))
                val rutInspector = getString(getColumnIndexOrThrow(DatabaseHelper.COLUMN_RUT_INSPECTOR))
                val nombreLocal = getString(getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOMBRE_LOCAL))
                val direccion = getString(getColumnIndexOrThrow(DatabaseHelper.COLUMN_DIRECCION))
                val infraccion = getString(getColumnIndexOrThrow(DatabaseHelper.COLUMN_INFRACCION))
                infracciones.add(Infraccion(folio, rutInspector, nombreLocal, direccion, infraccion))
            }
        }
        return infracciones
    }
}
