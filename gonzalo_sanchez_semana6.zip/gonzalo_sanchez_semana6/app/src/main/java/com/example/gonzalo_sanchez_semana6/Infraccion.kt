package com.example.gonzalo_sanchez_semana6


data class Infraccion(
    val folio: Long,
    val rutInspector: String,
    val nombreLocal: String,
    val direccion: String,
    val infraccion: String
)
