package com.example.gonzalo_sanchez_semana6

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var infraccionRepository: InfraccionRepository
    private lateinit var listViewInfracciones: ListView
    private lateinit var buttonAddInfraccion: Button
    private lateinit var buttonShareInfracciones: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        infraccionRepository = InfraccionRepository(this)

        listViewInfracciones = findViewById(R.id.listViewInfracciones)
        buttonAddInfraccion = findViewById(R.id.buttonAddInfraccion)
        buttonShareInfracciones = findViewById(R.id.buttonShareInfracciones)

        buttonAddInfraccion.setOnClickListener {
            startActivity(Intent(this, AddInfraccionActivity::class.java))
        }

        buttonShareInfracciones.setOnClickListener {
            shareAllInfracciones()
        }

        listViewInfracciones.setOnItemClickListener { _, _, position, _ ->
            val infraccion = infraccionRepository.getAllInfracciones()[position]
            val intent = Intent(this, EditInfraccionActivity::class.java).apply {
                putExtra("folio", infraccion.folio)
                putExtra("rutInspector", infraccion.rutInspector)
                putExtra("nombreLocal", infraccion.nombreLocal)
                putExtra("direccion", infraccion.direccion)
                putExtra("infraccion", infraccion.infraccion)
            }
            startActivity(intent)
        }

        listViewInfracciones.setOnItemLongClickListener { _, _, position, _ ->
            val infraccion = infraccionRepository.getAllInfracciones()[position]
            shareInfraccion(infraccion)
            true
        }

        loadInfracciones()
    }

    override fun onResume() {
        super.onResume()
        loadInfracciones()
    }

    private fun loadInfracciones() {
        val infracciones = infraccionRepository.getAllInfracciones()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, infracciones.map {
            "Folio: ${it.folio}, Local: ${it.nombreLocal}"
        })
        listViewInfracciones.adapter = adapter
    }

    private fun shareInfraccion(infraccion: Infraccion) {
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "Folio: ${infraccion.folio}\n" +
                    "RUT Inspector: ${infraccion.rutInspector}\n" +
                    "Nombre del Local: ${infraccion.nombreLocal}\n" +
                    "Dirección: ${infraccion.direccion}\n" +
                    "Infracción: ${infraccion.infraccion}")
            type = "text/plain"
        }
        startActivity(Intent.createChooser(shareIntent, "Compartir Infracción"))
    }

    private fun shareAllInfracciones() {
        val infracciones = infraccionRepository.getAllInfracciones()
        val infraccionesText = infracciones.joinToString("\n") { infraccion ->
            "Folio: ${infraccion.folio}\n" +
            "RUT Inspector: ${infraccion.rutInspector}\n" +
            "Nombre del Local: ${infraccion.nombreLocal}\n" +
            "Dirección: ${infraccion.direccion}\n" +
            "Infracción: ${infraccion.infraccion}\n\n"
        }

        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, infraccionesText)
            type = "text/plain"
        }
        startActivity(Intent.createChooser(shareIntent, "Compartir Todas las Infracciones"))
    }
}
