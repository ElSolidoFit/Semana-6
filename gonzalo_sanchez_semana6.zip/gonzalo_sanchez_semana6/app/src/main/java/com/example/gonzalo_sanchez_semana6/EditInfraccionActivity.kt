package com.example.gonzalo_sanchez_semana6

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gonzalo_sanchez_semana6.R

class EditInfraccionActivity : AppCompatActivity() {

    private lateinit var editTextRutInspector: EditText
    private lateinit var editTextNombreLocal: EditText
    private lateinit var editTextDireccion: EditText
    private lateinit var editTextInfraccion: EditText
    private lateinit var buttonUpdateInfraccion: Button

    private lateinit var infraccionRepository: InfraccionRepository

    private var folio: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_infraccion)

        infraccionRepository = InfraccionRepository(this)

        editTextRutInspector = findViewById(R.id.editTextRutInspector)
        editTextNombreLocal = findViewById(R.id.editTextNombreLocal)
        editTextDireccion = findViewById(R.id.editTextDireccion)
        editTextInfraccion = findViewById(R.id.editTextInfraccion)
        buttonUpdateInfraccion = findViewById(R.id.buttonUpdateInfraccion)

        folio = intent.getLongExtra("folio", 0)
        val rutInspector = intent.getStringExtra("rutInspector") ?: ""
        val nombreLocal = intent.getStringExtra("nombreLocal") ?: ""
        val direccion = intent.getStringExtra("direccion") ?: ""
        val infraccion = intent.getStringExtra("infraccion") ?: ""

        editTextRutInspector.setText(rutInspector)
        editTextNombreLocal.setText(nombreLocal)
        editTextDireccion.setText(direccion)
        editTextInfraccion.setText(infraccion)

        buttonUpdateInfraccion.setOnClickListener {
            updateInfraccion()
        }
    }

    private fun updateInfraccion() {
        val rutInspector = editTextRutInspector.text.toString()
        val nombreLocal = editTextNombreLocal.text.toString()
        val direccion = editTextDireccion.text.toString()
        val infraccion = editTextInfraccion.text.toString()

        if (rutInspector.isNotEmpty() && nombreLocal.isNotEmpty() && direccion.isNotEmpty() && infraccion.isNotEmpty()) {
            infraccionRepository.updateInfraccion(folio, rutInspector, nombreLocal, direccion, infraccion)
            Toast.makeText(this, "Infracción actualizada", Toast.LENGTH_LONG).show()
            finish()
        } else {
            Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show()
        }
    }
}
